$(document).ready(function () {

    // Check if page is reloaded and reload if not
    // if (!sessionStorage.getItem('reloaded')) {
    //     sessionStorage.setItem('reloaded', 'true');
    //     location.reload();
    // }

    // Function to get cookie value by name
    function getCookie(name) {
        const cookieValue = document.cookie.split('; ').find(row => row.startsWith(name + '='));
        const value = cookieValue ? cookieValue.split('=')[1] : null;
        return value ? decodeURIComponent(value) : null;
    }

    // Function to present products in the cart
    function presentProducts(prods) {
        let proplace = $("#products_place");
        proplace.empty(); // Clear existing products
        prods.forEach(function (obj) {
            let tempobj = $("<div></div>").addClass("col-md-4 mb-4");
            let card = $("<div></div>").addClass("card");
            let cardBody = $("<div></div>").addClass("card-body text-center");
            let img = $("<img>").attr("src", "static_content/images/image.jpg").addClass("card-img-top");
            let productName = $("<h5></h5>").addClass("card-title").text(obj.name);
            let price = $("<p></p>").addClass("card-text").text("Price: " + obj.price);
            let decreaseButton = $("<button></button>").addClass("btn btn-secondary mr-1 decreaseQuantity").text("-");
            decreaseButton.attr("value", obj.proid);
            let quantity = $("<span></span>").text("Quantity: " + obj.quantity);
            let increaseButton = $("<button></button>").addClass("btn btn-secondary ml-1 increaseQuanity").text("+");
            increaseButton.attr("value", obj.proid);
            cardBody.append(img, productName, price, decreaseButton, quantity, increaseButton);
            card.append(cardBody);
            tempobj.append(card);
            proplace.append(tempobj);
        });

        // Increase quantity button click event
        $(".increaseQuanity").click(function () {
            let userProducts = JSON.parse(localStorage.getItem("cart_objs"));
            let currQuantity = userProducts[this.value] + 1;
            userProducts[this.value] = currQuantity;
            $(this).closest(".card-body").find("span").text("Quantity: " + currQuantity);
            $(this).closest(".card-body").find(".decreaseQuantity").prop("disabled", false);
            localStorage.setItem("cart_objs", JSON.stringify(userProducts));
        });

        // Decrease quantity button click event
        $(".decreaseQuantity").click(function () {
            let userProducts = JSON.parse(localStorage.getItem("cart_objs"));
            let currQuantity = userProducts[this.value] - 1;
            userProducts[this.value] = currQuantity;
            $(this).closest(".card-body").find("span").text("Quantity: " + currQuantity);
            localStorage.setItem("cart_objs", JSON.stringify(userProducts));
            if (userProducts[this.value] == 1) {
                $(this).prop("disabled", true);
                return;
            }
        });
    }

    // Proceed to checkout button click event
    $("#toCheckOut").on("click", function () {
        let jsonString = localStorage.getItem("cart_objs");
        let cookieString = "cart_objs" + "=" + encodeURIComponent(jsonString);
        document.cookie = cookieString;
        window.location.href = "http://localhost:8081/com/checkOut";
    });

    // Get user products from cookie and present them
    let userProducts = JSON.parse(getCookie("userProducts"))["userProducts"];
    console.log(userProducts);
    presentProducts(userProducts);
});
