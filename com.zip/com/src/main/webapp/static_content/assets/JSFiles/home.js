$(document).ready(function () {
    var selected_items = {};
    localStorage.setItem("cart_objs", JSON.stringify(selected_items));

    function presentProducts(prods) {
        let proplace = $("#products_place");
        proplace.empty(); // Clear previous products

        for (let i = 0; i < prods.length; i++) {
            let obj = prods[i];

            let tempobj = $("<div></div>").addClass("col-md-4 mb-4");

            let card = $("<div></div>").addClass("card");
            tempobj.append(card);

            let imgdiv = $("<div></div>").addClass("imageProduct");
            card.append(imgdiv);

            let imgobj = $("<img>").attr("src", "static_content/images/image.jpg").addClass("card-img-top orgImage");
            imgdiv.append(imgobj);

            let cardBody = $("<div></div>").addClass("card-body");
            card.append(cardBody);

            let brand = $("<h5></h5>").addClass("card-title").text(obj["brand"]);
            cardBody.append(brand);

            let title = $("<h5></h5>").addClass("card-title").text(obj["name"]);
            cardBody.append(title);

            let mrp = $("<p></p>").addClass("card-text").html("<s style='color: red;'>" + "MRP: " + obj["mrp"] + "</s>");
            cardBody.append(mrp);

            let price = $("<p></p>").addClass("card-text").html("<span style='color: green;'>" + "Price: " + obj["price"] + "</span>");
            cardBody.append(price);
            if (obj["stock"] === 0) {
                let btn = $("<button></button>").addClass("btn btn-primary outOfStock").prop("disabled", true).text("Out Of Stock");
                cardBody.append(btn);
            }
            else {
                let btn = $("<button></button>").addClass("btn btn-primary addToCart").attr("value", obj["proid"]).text("Add to Cart");
                cardBody.append(btn);
            }

            proplace.append(tempobj);
        }

        $(".addToCart").click(function () {
            let pincodeForm = $("<form></form>").addClass("pincodeForm");
            let pincodeInput = $("<input>").attr("type", "text").attr("placeholder", "Enter Pincode");
            let submitButton = $("<input>").attr("type", "submit").val("Submit");

            pincodeForm.append(pincodeInput);
            pincodeForm.append(submitButton);

            let productDiv = $(this).closest(".card");

            productDiv.append(pincodeForm);

            pincodeForm.submit(function (event) {
                event.preventDefault();
                let productId = $(this).closest(".card").find(".addToCart").val();
                let pincode = pincodeInput.val();
                $.ajax({
                    url: "http://localhost:8081/com/checkStatus",
                    method: "GET",
                    data: {
                        "proid": productId,
                        "user_pincode": pincode
                    },
                    success: function (result) {
                        console.log(result["Deliverable"]);
                        console.log(typeof result["Deliverable"]);
                        console.log(result);
                        // if (result["Deliverable"]) {
                        //     let obj = JSON.parse(localStorage.getItem("cart_objs"));
                        //     if (obj[productId] !== undefined) {
                        //         obj[productId] = obj[productId] + 1;
                        //     } else {
                        //         obj[productId] = 1;
                        //     }
                        //     localStorage.setItem("cart_objs", JSON.stringify(obj));
                        //     console.log(JSON.parse(localStorage.getItem("cart_objs")));
                        //     $(this).closest(".card").append($("<p></p>").text("Deliverable, Added to Cart"));

                        // } else {
                        //     $(this).closest(".card").append($("<p></p>").text("Not deliverable to this pincode"));
                        //     return;
                        // }

                        let obj = JSON.parse(localStorage.getItem("cart_objs"));
                        if (obj[productId] !== undefined) {
                            obj[productId] = obj[productId] + 1;
                        } else {
                            obj[productId] = 1;
                        }
                        localStorage.setItem("cart_objs", JSON.stringify(obj));
                        console.log(JSON.parse(localStorage.getItem("cart_objs")));
                        $(this).closest(".card").append($("<p></p>").text("Deliverable, Added to Cart"));

                    }
                })

                // Remove the pincode form after submission
                $(this).remove();
            });
        });
    }

    $.ajax({
        url: "http://localhost:8081/com/products",
        method: "GET",
        success: function (result) {
            let prods = result["products"];
            console.log(prods);
            presentProducts(prods);
        }
    });

    $("#category_space").on("change", function () {
        $.ajax({
            url: "http://localhost:8081/com/catProducts",
            method: "GET",
            data: {
                "category_id": $("#category_space").val()
            },
            success: function (result) {
                $("#sort_fun").find("#default_sort").prop("selected", true);
                let prods = result["products"];
                console.log("From category");
                console.log(prods);
                presentProducts(prods);
            }
        });
    })

    $("#sort_func").on("change", function () {
        $.ajax({
            url: "http://localhost:8081/com/productSorter",
            method: "GET",
            data: {
                "category_id": $("#category_space").val(),
                "sort_val": $("#sort_func").val()
            },
            success: function (result) {
                let prods = result["products"];
                console.log("From sort");
                console.log(prods);
                presentProducts(prods);
            }
        });
    })

    $.ajax({
        url: "http://localhost:8081/com/categories",
        method: "GET",
        success: function (result) {
            let cats = result["categories"];
            let cat_space = $("#category_space");

            for (let i = 0; i < cats.length; i++) {
                let cat = cats[i];
                let opt = $("<option></option>").text(cat["catname"]);
                opt.attr("value", cat["catid"]);
                opt.attr("id", "productCategory");
                cat_space.append(opt);
            }
        }
    })

    $("#takeMeToCart").on("click", function () {
        let jsonString = localStorage.getItem("cart_objs");
        let cookieString = "cart_objs" + "=" + encodeURIComponent(jsonString);
        document.cookie = cookieString;
        window.location.assign("http://localhost:8081/com/cart");

        // window.location.href="http://localhost:8081/com/cart";
    })
});
