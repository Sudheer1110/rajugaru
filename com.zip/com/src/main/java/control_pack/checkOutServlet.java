package control_pack;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import DAOLayer.DAOFactory;
import DAOLayer.productInt;
import bll_pack.AmountAndProducts;
import model_pack.Product;
import model_pack.orderProduct;
import model_pack.productGST;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/checkOut")
public class checkOutServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		RequestDispatcher rd = rq.getRequestDispatcher("static_content/assets/HTMLFiles/checkout.html");

		Cookie[] cks = rq.getCookies();
		String decodedCookie = "";

		for (Cookie ck : cks) {
			if (ck.getName().equals("cart_objs")) {
				decodedCookie = URLDecoder.decode(ck.getValue(), "UTF-8");
			}
		}
		System.out.println("In checkout " + decodedCookie);

		JSONObject userprods = new JSONObject(decodedCookie);
		HashMap<Integer, Integer> userProdsQuan = new HashMap<>();
		productInt pdb = DAOFactory.getProductInt();
		ArrayList<Integer> prodIds = new ArrayList<>();
		int totalquantity = 0;

		for (String proid : userprods.keySet()) {
			int curr_proId = Integer.parseInt(proid);
			prodIds.add(curr_proId);
			totalquantity += userprods.getInt(proid);
			userProdsQuan.put(curr_proId, userprods.getInt(proid));
		}
		System.out.println("In checkout " + prodIds);
		System.out.println("In checkout " + userProdsQuan);

		ArrayList<productGST> cartProds = pdb.getProductsPriceAndGST(prodIds);
		ArrayList<orderProduct> orderProds = new ArrayList<>();

		for (productGST ele : cartProds) {
			System.out.println(ele.getProid() + "," + ele.getUnitprice() + "," + ele.getGst() + ","
					+ userProdsQuan.get(ele.getProid()));
			orderProduct curr = new orderProduct(ele.getProid(), ele.getUnitprice(), ele.getGst(),
					userProdsQuan.get(ele.getProid()));

			orderProds.add(curr);
		}
		System.out.println(orderProds);

		AmountAndProducts aapObj = new AmountAndProducts();

		double prosvalue = aapObj.getProductsValue(orderProds);

		double shippingcharge = pdb.getShippingCharge(prosvalue, totalquantity);
		System.out.println("Shipping charge per each is :" + shippingcharge);

		double totalPrice = aapObj.caluclateAmount(orderProds, shippingcharge);
		HashMap<Product, Integer> reqProducts = pdb.getReqProducts(prodIds, userProdsQuan);

		for (orderProduct ele : orderProds) {
			int quan = ele.getQuantity();
			double unitprice = ele.getUnitprice() + shippingcharge;
			double totalprice = unitprice + unitprice * (ele.getGst() / 100.0);
			ele.setTotalprice(totalprice * quan);
		}

		JSONObject outerjsobj = new JSONObject();
		ArrayList<JSONObject> jsobjsCart = new ArrayList<>();
		for (orderProduct ele : orderProds) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("product_id", ele.getProid());
			innerjsobj.put("unit_price", ele.getUnitprice());
			innerjsobj.put("gst", ele.getGst());
			innerjsobj.put("quantity", ele.getQuantity());
			innerjsobj.put("delivery_charge", ele.getQuantity() * shippingcharge);
			innerjsobj.put("total_price", ele.getTotalprice());
			jsobjsCart.add(innerjsobj);
		}
		outerjsobj.put("UserCheckoutProducts", jsobjsCart);
		outerjsobj.put("TotalOrderPrice", totalPrice);
		outerjsobj.put("Delivery_Fee", shippingcharge * totalquantity);

		rs.getWriter().write(outerjsobj.toString());

		@SuppressWarnings("deprecation")
		Cookie ck = new Cookie("checkOutProducts", URLEncoder.encode(outerjsobj.toString()));
		rs.addCookie(ck);

		rd.forward(rq, rs);
	}
}
