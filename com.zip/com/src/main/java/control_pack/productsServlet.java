package control_pack;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import DAOLayer.DAOFactory;
import DAOLayer.productInt;
import model_pack.Product;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/products")
public class productsServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		rs.setContentType("application/json");
		JSONObject outerjsobj = new JSONObject();
		productInt pdb = DAOFactory.getProductInt();

		ArrayList<Product> pls = pdb.getAllProducts();
		ArrayList<JSONObject> jsobjs = new ArrayList<>();

		// private int proid;
		// private String name;
		// private String brand;
		// private double mrp;
		// private double price;
		// private String hsncode;
		// private String imgpath;
		// private int catid;
		// private int stock;

		for (Product prod : pls) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("proid", prod.getProid());
			innerjsobj.put("name", prod.getName());
			innerjsobj.put("brand", prod.getBrand());
			innerjsobj.put("mrp", prod.getMrp());
			innerjsobj.put("price", prod.getPrice());
			innerjsobj.put("hsncode", prod.getHsncode());
			innerjsobj.put("imgpath", prod.getImgpath());
			innerjsobj.put("catid", prod.getCatid());
			innerjsobj.put("stock", prod.getStock());
			jsobjs.add(innerjsobj);
		}
		outerjsobj.put("products", jsobjs);
		PrintWriter pw = rs.getWriter();
		pw.write(outerjsobj.toString());
	}
}
