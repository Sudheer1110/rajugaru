package db_pack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import DAOLayer.productInt;
import model_pack.Product;
import model_pack.productGST;

public class productDb implements productInt {
	public Connection conn = null;

	public productDb() {
		conn = connClass.getConnection();
	}

	public ArrayList<Product> getAllProducts() {
		ArrayList<Product> pls = new ArrayList<>();

		// returns table(
		// proid int,
		// name varchar(100),
		// price bigint,
		// hsncode varchar(10),
		// imgpath varchar(1000),
		// catid int
		// )

		try {
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rst = st.executeQuery("select * from allProducts6()");

			// proid INT,
			// name VARCHAR,
			// brand VARCHAR,
			// mrp numeric,
			// price numeric,
			// hsncode VARCHAR,
			// imgpath VARCHAR,
			// catid INT,
			// stock INT

			while (rst.next()) {
				// System.out.println(rst.getInt(1) + "," + rst.getString(2) + "," + rst.getString(3) + ","
				// + rst.getDouble(4) + "," + rst.getDouble(5) + "," + rst.getString(6) + "," + rst.getString(7)
				// + "," + rst.getInt(8) + "," + rst.getInt(9));
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4),
						rst.getDouble(5), rst.getString(6), rst.getString(7), rst.getInt(8), rst.getInt(9));
				pls.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public ArrayList<Product> getAllCategoryProducts(int catid) {
		if (catid == -1) {
			return this.getAllProducts();
		}
		ArrayList<Product> pls = new ArrayList<>();

		try {
			PreparedStatement st = conn.prepareStatement("select * from allCategoryProducts6(?)",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setInt(1, catid);
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4),
						rst.getDouble(5), rst.getString(6), rst.getString(7), rst.getInt(8), rst.getInt(9));
				pls.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public HashMap<Product, Integer> getReqProducts(ArrayList<Integer> proids, HashMap<Integer, Integer> proQuantity) {

		HashMap<Product, Integer> pls = new HashMap<>();

		try {
			PreparedStatement st = conn.prepareStatement("select * from allRequiredProducts6(?)",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setArray(1, conn.createArrayOf("INTEGER", proids.toArray(new Integer[0])));
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4),
						rst.getDouble(5), rst.getString(6), rst.getString(7), rst.getInt(8), rst.getInt(9));
				pls.put(temp, proQuantity.get(rst.getInt(1)));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public ArrayList<productGST> getProductsPriceAndGST(ArrayList<Integer> proids) {
		ArrayList<productGST> pgsts = new ArrayList<>();

		try {
			PreparedStatement st = conn.prepareStatement("\r\n" + "SELECT\r\n" + "    p.prod_id,\r\n"
					+ "    s.prod_price AS unitprice,\r\n" + "    h.hsnc_gstc_percentage AS gst\r\n" + "FROM\r\n"
					+ "    Products6 p\r\n" + "JOIN\r\n" + "    ProductStock6 s ON p.prod_id = s.prod_id\r\n"
					+ "JOIN\r\n" + "    HSNCodes6 h ON p.prod_hsnc_id = h.hsnc_id\r\n" + "WHERE\r\n"
					+ "    p.prod_id = ANY(?);", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setArray(1, conn.createArrayOf("INTEGER", proids.toArray(new Integer[0])));
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				productGST temp = new productGST(rst.getInt(1), rst.getLong(2), rst.getFloat(3));
				pgsts.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pgsts;
	}

	@Override
	public boolean checkDeliveryStatus(int proid, int pincode) {
		try {
			PreparedStatement st = conn.prepareStatement("select * from statusCheck6(?,?)");

			st.setInt(1, proid);
			st.setInt(2, pincode);
			ResultSet rst = st.executeQuery();
			if (rst.next()) {
				if (rst.getBoolean(1)) {
					return true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public double getShippingCharge(double totalPrice, int totalquantity) {
		double res = 0;
		try {
			// error coming as function getordershippingprice(double precision) does not exist so used directly
			PreparedStatement st = conn.prepareStatement("SELECT \r\n" + "    CASE \r\n"
					+ "        WHEN ? > (SELECT MAX(orvl_to) FROM OrderValueWiseShippingCharges6) THEN \r\n"
					+ "            (SELECT orvl_shippingamount FROM OrderValueWiseShippingCharges6 ORDER BY orvl_to DESC LIMIT 1)\r\n"
					+ "        ELSE \r\n"
					+ "            (SELECT orvl_shippingamount FROM OrderValueWiseShippingCharges6 WHERE ? BETWEEN orvl_from AND orvl_to)\r\n"
					+ "    END AS shipping_amount;\r\n" + "", ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			st.setDouble(1, totalPrice);
			st.setDouble(2, totalPrice);
			ResultSet rst = st.executeQuery();
			if (rst.next()) {
				res = rst.getDouble(1) / totalquantity;
				System.out.println("per unit is :" + res);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
}
