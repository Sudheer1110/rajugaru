package DAOLayer;

import java.util.ArrayList;

import model_pack.Category;

public interface categoryInt {
	public ArrayList<Category> getAllCategories();
}
