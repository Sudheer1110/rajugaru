package DAOLayer;

import java.util.ArrayList;

import model_pack.Order;
import model_pack.orderProduct;

public interface orderInt {
	public Order createOrder(double totalPrice);

	public void createOrderProducts(ArrayList<orderProduct> userProds, Order ord);
}
