package DAOLayer;

import java.util.ArrayList;
import java.util.HashMap;

import model_pack.Product;
import model_pack.productGST;

public interface productInt {
	public ArrayList<Product> getAllProducts();

	public ArrayList<Product> getAllCategoryProducts(int catid);

	public HashMap<Product, Integer> getReqProducts(ArrayList<Integer> proids, HashMap<Integer, Integer> proQuantity);

	public ArrayList<productGST> getProductsPriceAndGST(ArrayList<Integer> proids);

	public boolean checkDeliveryStatus(int proid, int pincode);

	public double getShippingCharge(double totalPrice, int totalquantity);
}
