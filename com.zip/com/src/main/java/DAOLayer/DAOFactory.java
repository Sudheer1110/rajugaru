package DAOLayer;

import db_pack.categoryDB;
import db_pack.orderDB;
import db_pack.productDb;

public class DAOFactory {
	private static categoryDB cdb = null;
	private static productDb pdb = null;
	private static orderDB odb = null;

	public static categoryInt getCategoryInt() {
		if (cdb == null) {
			cdb = new categoryDB();
		}
		return cdb;
	}

	public static productInt getProductInt() {
		if (pdb == null) {
			pdb = new productDb();
		}
		return pdb;
	}

	public static orderInt getOrderInt() {
		if (odb == null) {
			odb = new orderDB();
		}
		return odb;
	}
}
