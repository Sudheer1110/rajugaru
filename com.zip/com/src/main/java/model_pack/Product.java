package model_pack;

// create table products25 (
// proid serial primary key,
// name varchar(100),
// price bigint,
// hsncode varchar(10),
// imgpath varchar(1000),
// catid int
// )

public class Product {
	private int proid;
	private String name;
	private String brand;
	private double mrp;
	private double price;
	private String hsncode;
	private String imgpath;
	private int catid;
	private int stock;

	public Product(int proid, String name, String brand, double price, double mrp, String hsncode, String imgpath,
			int catid, int stock) {
		this.proid = proid;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.mrp = mrp;
		this.hsncode = hsncode;
		this.imgpath = imgpath;
		this.catid = catid;
		this.stock = stock;
	}

	public int getProid() {
		return proid;
	}

	public void setProid(int proid) {
		this.proid = proid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getMrp() {
		return mrp;
	}

	public void setMrp(double mrp) {
		this.mrp = mrp;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getHsncode() {
		return hsncode;
	}

	public void setHsncode(String hsncode) {
		this.hsncode = hsncode;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}

	public int getCatid() {
		return catid;
	}

	public void setCatid(int catid) {
		this.catid = catid;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

}
