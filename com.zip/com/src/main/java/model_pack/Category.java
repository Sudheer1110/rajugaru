package model_pack;

// create table categories25(
// catid serial primary key,
// catname varchar(100) unique not null
// )

public class Category {
	private int catid;
	private String catname;
	private String desc;

	public Category(int catid, String catname, String desc) {
		super();
		this.catid = catid;
		this.catname = catname;
		this.desc = desc;
	}

	public int getCatid() {
		return catid;
	}

	public void setCatid(int catid) {
		this.catid = catid;
	}

	public String getCatname() {
		return catname;
	}

	public void setCatname(String catname) {
		this.catname = catname;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
