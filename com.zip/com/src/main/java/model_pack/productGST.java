package model_pack;

public class productGST {
	private int proid;
	private long unitprice;
	private float gst;

	public productGST(int proid, long unitprice, float gst) {
		this.proid = proid;
		this.unitprice = unitprice;
		this.gst = gst;
	}

	public int getProid() {
		return proid;
	}

	public void setProid(int proid) {
		this.proid = proid;
	}

	public long getUnitprice() {
		return unitprice;
	}

	public void setUnitprice(long unitprice) {
		this.unitprice = unitprice;
	}

	public float getGst() {
		return gst;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}
}
