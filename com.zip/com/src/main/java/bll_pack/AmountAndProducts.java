package bll_pack;

import java.util.ArrayList;

import model_pack.orderProduct;

public class AmountAndProducts {
	public double caluclateAmount(ArrayList<orderProduct> orderPros, double shippingcharge) {
		double total = 0;
		for (orderProduct prod : orderPros) {
			System.out.println("Unit Price without shipping: " + prod.getUnitprice());
			double unitprice = prod.getUnitprice() + shippingcharge;
			System.out.println("Unit Price with shipping: " + unitprice);
			total += (unitprice + (prod.getGst() / 100.0) * unitprice) * prod.getQuantity();
		}
		return total;
	}

	public double getProductsValue(ArrayList<orderProduct> orderProds) {
		double total = 0;
		for (orderProduct prod : orderProds) {
			total += prod.getUnitprice() * prod.getQuantity();
		}
		return total;
	}
}
