package bll_pack;

import java.util.Comparator;

import model_pack.Product;

public class ProductsNameSorter implements Comparator<Product> {

	@Override
	public int compare(Product p1, Product p2) {
		return p1.getName().compareTo(p2.getName());
	}

}
